<?php $__env->startSection('subtitle', 'Spells'); ?>
<?php $__env->startSection('content'); ?>
    <body>
        <h2>Welcome to D&amp;D&nbsp; 5e Rules Spells</h2>
        <p>List of classes</p>
        <form action="foundClasses" method="post">
            <p>clas: </p> <input type="int" name="level" value="1" id="level"/>
            <br/>
            <button type="submit"><strong>zoek via submit</strong></button>
        </form>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/classes.blade.php ENDPATH**/ ?>