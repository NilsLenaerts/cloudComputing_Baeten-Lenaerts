
<?php $__env->startSection('subtitle','Spells'); ?>
<?php $__env->startSection('content'); ?>
    <body class="spellList">
        <div  style="position:fixed; margin-bottom: 50px; margin-left: 500px">
            <h2 style="color: white">Welcome to D&amp;D&nbsp; 5e Rules Spells</h2>
            <p style="color: white">List of spells</p>
            <form action="spells" method="get">
                <p style="color: white">Level:  <input type="int" name="level" value="" id="level"/>
                    <button type="submit"><strong>Filter</strong></button>
                </p>
            </form>
        </div>

            <p>&nbsp;</p>
            <p>&nbsp;</p>

        <div style="margin-top: 100px; ">
            <ul class="spellList">
                <?php if(isset($spells)): ?>
                    <?php $__currentLoopData = $spells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><a href = "showSpell/<?php echo e($id->index); ?>" ><?php echo e($id->name); ?></a></strong></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/spells.blade.php ENDPATH**/ ?>