
<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h4><?php echo e($class->name); ?></h4>
    <h3>hit die: d<?php echo e($class->hit_die); ?></h3>


    <?php if(isset($class->proficiency_choices)): ?>
    <ul>
    <?php $__currentLoopData = $class->proficiency_choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof_choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p> Choose: <?php echo e($prof_choice->choose); ?> proficiencies</p>
    <p> From: 
        <ul>
            <?php $__currentLoopData = $prof_choice->from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $froms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($froms->name); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </ul>
    <?php endif; ?>


    <?php if(isset($class->proficiencies)): ?>
    <p>Proficiencies:</p>
    <ul>
    <?php $__currentLoopData = $class->proficiencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($prof->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </ul>
    <?php endif; ?>

    <?php if(isset($class->saving_throws)): ?>
    <p>Saving throws:</p>
    <ul>
    <?php $__currentLoopData = $class->saving_throws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($saves->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </ul>
    <?php endif; ?>

    <?php if(isset($class->subclasses)): ?>
    <p>subclasses:</p>
    <ul>
    <?php $__currentLoopData = $class->subclasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($sub->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </ul>
    <?php endif; ?>

</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/showClass.blade.php ENDPATH**/ ?>