<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Character <?php echo $__env->yieldContent('subtitle'); ?></title>
        <script type="text/javascript" src="functies.js">
        </script>
    </head>
    <body>
        <h1>Character</h1>
        <h2><?php echo $__env->yieldContent('subtitle'); ?></h2>
        <?php echo $__env->yieldContent('content'); ?>
        <div id="status" style="background-color: #ddd"></div>
        <hr/>
    </body>
</html><?php /**PATH C:\xampp\htdocs\BaetenMaarten_LenaertsNils\resources\views/master.blade.php ENDPATH**/ ?>