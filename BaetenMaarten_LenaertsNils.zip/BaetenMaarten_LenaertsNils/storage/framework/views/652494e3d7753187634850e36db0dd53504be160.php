<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/homebrew/foundhomebrewspells.blade.php ENDPATH**/ ?>