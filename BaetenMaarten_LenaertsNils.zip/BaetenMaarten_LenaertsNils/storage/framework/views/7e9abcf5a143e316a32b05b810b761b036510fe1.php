<?php $__env->startSection('subtitle', 'Charactertje'); ?>
<?php $__env->startSection('content'); ?>
    <h3>With this Application you can generate random D&D 5e characters</h3>
    <p>To create your own random character. Click the following link <a href="generateCharacter">generateCharacter</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BaetenMaarten_LenaertsNils\resources\views/Characters/index.blade.php ENDPATH**/ ?>