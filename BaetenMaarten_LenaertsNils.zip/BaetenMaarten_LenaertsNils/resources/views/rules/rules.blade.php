@extends('master')
@section('subtitle', 'Rules')
@section('content')
    <body class="rules" >
        <div style="text-align: center;">
            <h2 style="color:white">Welcome to D&amp;D&nbsp; 5e Rules</h2>
            <p style="color:white">For list of spells press <a style="color:white; text-decoration: underline;" href="spells">Spells</a></p>
            <p style="color:white">For list of classes press <a style="color:white; text-decoration: underline;" href="classes">Classes</a></p>
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
    </body>
@stop
