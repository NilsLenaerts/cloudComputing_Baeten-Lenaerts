@extends('master')
@section('subtitle', 'Charactertje')
@section('content')
    <h3>With this Application you can generate random D&D 5e characters</h3>
    <p>To create your own random character. Click the following link <a href="generateCharacter">generateCharacter</a></p>
@stop
