<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
    <body class="show-background-image background">
        <h3><?php echo e($spell->name); ?></h3>
        <h4><i>School of magic: <?php echo e($spell->school->name); ?></i></h4>
        <h4>Casting Time: <?php echo e($spell->casting_time); ?></h4>
        <h4>Range: <?php echo e($spell->range); ?></h4>
        <?php if(isset($spell->area_of_effect)): ?>
            <h4>Area of effect: <?php echo e($spell->area_of_effect->size); ?> foot  <?php echo e($spell->area_of_effect->type); ?> </h4>
        <?php endif; ?>
        <?php if(isset($spell->components)): ?>
        <h4>Components:</h4>
            <ul>
                <?php $__currentLoopData = $spell->components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($component); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </ul>
        <?php endif; ?>
        <?php if(isset($spell->material)): ?>
            <p>Material: <?php echo e($spell->material); ?></p>
        <?php endif; ?>
        <?php if($spell->ritual): ?>
        <p>Ritual</p>
        <?php endif; ?>
        <p>Duration: <?php echo e($spell->duration); ?></p>
        <?php if($spell->concentration): ?>
        <p>Concentration</p>
        <?php endif; ?>
        <p>Spell Level: <?php echo e($spell->level); ?></p>
        <?php if(isset($spell->desc)): ?>
        <p>Description:</p>
            <?php $__currentLoopData = $spell->desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($description); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        <?php endif; ?>
        <?php if(isset($spell->higher_level)): ?>
            <p>At higher level: <?php echo e($spell->higher_level[0]); ?></p>
        <?php endif; ?>

        <p>Available to:</p>
        <ul>
            <?php $__currentLoopData = $spell->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($class->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/spells/showSpell.blade.php ENDPATH**/ ?>