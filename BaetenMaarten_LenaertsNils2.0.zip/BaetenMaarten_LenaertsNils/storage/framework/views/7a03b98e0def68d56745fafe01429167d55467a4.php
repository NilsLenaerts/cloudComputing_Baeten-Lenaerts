<?php $__env->startSection("pagina","Races"); ?>
<?php $__env->startSection("content"); ?>
<body class="spellList">
    <ul>
        <?php $__currentLoopData = $monsters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><strong><a href = "showMonster/<?php echo e($id->index); ?>" ><?php echo e($id->name); ?></a></strong></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/monsters/foundMonsters.blade.php ENDPATH**/ ?>