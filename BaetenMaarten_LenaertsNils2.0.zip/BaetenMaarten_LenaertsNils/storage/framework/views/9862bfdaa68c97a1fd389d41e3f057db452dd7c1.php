<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h4><?php echo e($race->name); ?></h4>
    <h3>Speed :<?php echo e($race->speed); ?></h3>
    
    <?php if(isset($race->ability_bonuses)): ?>
        <ul>
        <?php $__currentLoopData = $race->ability_bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bonuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> Ability score: <?php echo e($bonuses->ability_score->name); ?> +<?php echo e($bonuses->bonus); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
    <p> Alignment: <?php echo e($race->alignment); ?></p>
    <p> Age: <?php echo e($race->age); ?></p>
    <p> Size: <?php echo e($race->size); ?></p>
    <p> size description: <?php echo e($race->size_description); ?></p>
    
    <?php if(isset($race->starting_proficiencies)): ?>
    <p> You are proficient in: </p>
        <ul>
        <?php $__currentLoopData = $race->starting_proficiencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($profs->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
    <!-- werkt nog niet 
    <?php if(isset($race->starting_proficiency_options)): ?>
    <ul>
    <?php $__currentLoopData = $race->starting_proficiency_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof_options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p> Choose: <?php echo e($prof_options->choose); ?> proficiencies</p>
    <p> From: 
        <ul>
            <?php $__currentLoopData = $prof_options->from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $froms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($froms->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </ul>
    <?php endif; ?>
    -->
    
    <?php if(isset($race->languages)): ?>
     <p> Language description: <?php echo e($race->language_desc); ?></p>
        <ul>
        <?php $__currentLoopData = $race->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($language->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
    <?php if(isset($race->traits)): ?>
    <p> You have the following traits: </p>
        <ul>
        <?php $__currentLoopData = $race->traits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/showTrait/<?php echo e($trait->index); ?>"><?php echo e($trait->name); ?> </a></li> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
    <?php if(isset($race->subraces)): ?>
    <p> Subraces: </p>
        <ul>
        <?php $__currentLoopData = $race->subraces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subrace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/showSubrace/<?php echo e($subrace->index); ?>"><?php echo e($subrace->name); ?> </a></li> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/showRace.blade.php ENDPATH**/ ?>