<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h3><?php echo e($subclass->name); ?></h3>
    
    <?php if(isset($subclass->desc )): ?>
        <?php $__currentLoopData = $subclass->desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($description); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    <?php endif; ?>
 
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/classes/showSubclass.blade.php ENDPATH**/ ?>