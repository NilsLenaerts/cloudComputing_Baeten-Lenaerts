<?php $__env->startSection('subtitle','Homebrew'); ?>
<?php $__env->startSection('content'); ?>
    <body class="homebrew">
        <h2 style="color: white">Welcome to D&amp;D&nbsp; 5e homebrew creator</h2>
        <p style="color: white"> Here's the short definition of homebrew as it 
            relates to Dungeons and Dragons (also known as D&D):</p>
        <p style="color: white"><e>“Any content within a Dungeons and Dragons game that cannot be found in an official rulebook.”<e></p>
        <p >&nbsp;</p>
        <p>&nbsp;</p>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/homebrew/homebrew.blade.php ENDPATH**/ ?>