<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h3><?php echo e($homebrewSpell->name); ?></h3>
    <h4>Casting Time: <?php echo e($homebrewSpell->castingTime); ?></h4>  
    <p>Spell Level: <?php echo e($homebrewSpell->level); ?></p>
    <p>components: <?php echo e($homebrewSpell->components); ?></p>
    <p>materials: <?php echo e($homebrewSpell->materials); ?></p>
    <p>description: <?php echo e($homebrewSpell->description); ?></p>
    <p>school: <?php echo e($homebrewSpell->school); ?></p>
    <p>range: <?php echo e($homebrewSpell->range); ?></p>
    <p>ritual: <?php echo e($homebrewSpell->ritual); ?></p>
    <p>availability: <?php echo e($homebrewSpell->availability); ?></p>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/homebrew/showHomebrewSpell.blade.php ENDPATH**/ ?>