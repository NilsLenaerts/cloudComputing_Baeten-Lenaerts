
<?php $__env->startSection('subtitle',"Home"); ?>
<?php $__env->startSection('content'); ?>

    <div class="border-box padding-2">
        <!-- <h1 class="blackRedShadow  center" >Home</h1> -->
        <h2 class=" center margin-0 padding-0 font-family-draconis" >Welcome to D&amp;D&nbsp;</h2>
        <p class="center"><img src="https://dnd.wizards.com/sites/all/themes/dx/logo.png" width="382" height="64" /></p>
        <p class="center font-family-draconis"><em>&nbsp;May the die be in your favor</em></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/home.blade.php ENDPATH**/ ?>