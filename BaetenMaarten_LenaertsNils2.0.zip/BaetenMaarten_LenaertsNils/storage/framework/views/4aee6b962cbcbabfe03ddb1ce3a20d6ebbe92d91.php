<?php $__env->startSection('subtitle', 'Homebrew creator'); ?>
<?php $__env->startSection('content'); ?>
    <body>
        <style> </style>
        <h2>Welcome to D&amp;D&nbsp; 5e homebrew creator</h2>
        <p>Name:  <input type="string" name="name" value="" id="name"/></p>
        <p>Casting Time:  <input type="string" name="castingTime" value="" id="castingTime"/></p>
        <p>Level:  <input type="int" name="level" value="" id="level"/></p>  
        <button type="button" onclick="saveSpell()"><strong>Save</strong></button> 
        <p>&nbsp;</p>
        <p>&nbsp;</p>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/homebrew/homebrewspellcreator.blade.php ENDPATH**/ ?>