
<?php $__env->startSection("pagina","Homebrew items"); ?>

<?php $__env->startSection("content"); ?>
    <body class="spellList">
        <div style="position:fixed; margin-bottom: 500px; margin-left: 500px">
            <h2>Welcome to D&amp;D&nbsp; 5e homebrew creator</h2>
            <p>Name:  <input type="string" name="name" value="name" id="name"/></p>
            <p>Price:  <input type="string" name="price" value="price" id="price"/></p>
            <p>Description:  <input type="string" name="description" value="Description" id="description"/></p>  
            <button type="button" onclick="saveItem()"><strong>Save</strong></button> 
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</p>

        <div style="margin-top: 200px; ">
            <ul class="spellList">
                <?php if(isset($homebrewItems)): ?>
                    <?php $__currentLoopData = $homebrewItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><a href = "showHomebrewItem/<?php echo e($id->name); ?>" ><?php echo e($id->name); ?></a></strong></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/homebrew/foundHomebrewItems.blade.php ENDPATH**/ ?>