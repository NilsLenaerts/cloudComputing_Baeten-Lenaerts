<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h4><?php echo e($monster->name); ?></h4>
    <p> <?php echo e($monster->size); ?></p>
    <p> <?php echo e($monster->type); ?></p>
    <p> <?php echo e($monster->alignment); ?></p>
    <p> <?php echo e($monster->armor_class); ?></p>
    <p> <?php echo e($monster->hit_points); ?> : <?php echo e($monster->hit_dice); ?></p>
    <p>strength: <?php echo e($monster->strength); ?></p>
    <p>dexterity: <?php echo e($monster->dexterity); ?></p>
    <p>constitution: <?php echo e($monster->constitution); ?></p>
    <p>intelligence: <?php echo e($monster->intelligence); ?></p>
    <p>charisma: <?php echo e($monster->charisma); ?></p>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/monsters/showMonster.blade.php ENDPATH**/ ?>