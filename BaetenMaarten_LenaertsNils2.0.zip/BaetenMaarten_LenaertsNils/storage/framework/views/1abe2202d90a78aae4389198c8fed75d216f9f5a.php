<?php $__env->startSection("pagina","..."); ?>

<?php $__env->startSection("content"); ?>
<body class="show">
    <h3><?php echo e($subrace->name); ?></h3>
    
    <p>Description: <?php echo e($subrace->desc); ?></p>
    
    <?php if(isset($subrace->ability_bonuses)): ?>
        <ul>
        <?php $__currentLoopData = $subrace->ability_bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bonuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> Ability score: <?php echo e($bonuses->ability_score->name); ?> +<?php echo e($bonuses->bonus); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
    <?php if(isset($subrace->racial_traits)): ?>
    <p> You have the following racial traits: </p>
        <ul>
        <?php $__currentLoopData = $subrace->racial_traits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/showTrait/<?php echo e($trait->index); ?>"><?php echo e($trait->name); ?> </a></li> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </ul>
    <?php endif; ?>
    
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maarten\Documents\IIW\Ma\Cloud computing\Taak\cloudComputing_Baeten-Lenaerts\BaetenMaarten_LenaertsNils\resources\views/rules/showSubrace.blade.php ENDPATH**/ ?>