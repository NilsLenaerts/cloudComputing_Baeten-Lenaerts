@extends('master')
@section('subtitle','Homebrew')
@section('content')
    <body class="homebrew">
        <h2 style="color: white">Welcome to D&amp;D&nbsp; 5e homebrew creator</h2>
        <p style="color: white"> Here's the short definition of homebrew as it 
            relates to Dungeons and Dragons (also known as D&D):</p>
        <p style="color: white"><e>“Any content within a Dungeons and Dragons game that cannot be found in an official rulebook.”<e></p>
        <p >&nbsp;</p>
        <p>&nbsp;</p>
    </body>
@stop
