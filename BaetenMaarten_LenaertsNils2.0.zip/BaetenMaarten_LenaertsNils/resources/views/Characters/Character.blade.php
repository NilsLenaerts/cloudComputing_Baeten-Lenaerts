@extends('master')
@section('subtitle', 'Your Character')
@section('content')
  
</header>
    <img src="https://media.dnd.wizards.com/styles/story_banner/public/images/head-banner/DX_CharacterSheet_Articles_Header-Image.jpg" alt="" width="1920/" height="600" /></em></p>   
@stop
