<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Http\Controllers;
header('Access-Control-Allow-Origin: *');
use Illuminate\Http\Request;

class homebrewController extends Controller{
    
    public function homebrew(){
        return view("homebrew/homebrew");
    }
    
    /*
     * geeft de lijst met homebrew spells terug
     */
    public function foundHomebrewSpells(Request $request){
        //$level=$request->level;
        error_log("hier");
        //$name=$request->name;
        //error_log($spells->results);
        error_log("hoer");
        $homebrewSpells= json_decode(file_get_contents("http://127.0.0.1:1200/api/searchspell"));
        return view("homebrew/foundHomebrewSpells")->with("homebrewSpells",$homebrewSpells);    
    }
    
    /*
    * Haalt de inhoud van een spell op
    */
    public function showHomebrewSpell($name){
        $name20 =rawurlencode($name);
        $homebrewSpell= json_decode(file_get_contents("http://127.0.0.1:1200/api/showHomebrewSpell/" . $name20));
        error_log(json_encode($homebrewSpell));
        return view("homebrew/showHomebrewSpell")->with("homebrewSpell",$homebrewSpell);  
    }

    //-----------------------------------------------------
        
    /*
     * geeft de lijst met homebrew items terug
     */
    public function foundHomebrewItems(Request $request){
        //$level=$request->level;
        error_log("hier");
        //$name=$request->name;
        //error_log($homebrewItems->results);
        error_log("hoer");
        $homebrewItems= json_decode(file_get_contents("http://127.0.0.1:1200/api/searchitem"));
        return view("homebrew/foundHomebrewItems")->with("homebrewItems",$homebrewItems);          
    }
    
    /*
    * Haalt de inhoud van een item op
    */
    public function showHomebrewItem($name){
        $name20 =rawurlencode($name);
        $homebrewItem= json_decode(file_get_contents("http://127.0.0.1:1200/api/showHomebrewItem/" . $name20));
        error_log(json_encode($homebrewItem));
        return view("homebrew/showHomebrewItem")->with("homebrewItem",$homebrewItem);  
    }
    
}
